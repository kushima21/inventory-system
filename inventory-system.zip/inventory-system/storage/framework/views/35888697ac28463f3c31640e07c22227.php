<?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile.css', 'resources/js/app.js']); ?>
<?php
    $user = \App\Models\User::find(session('user_id'));
?>

<?php $__env->startSection('Sidecontent'); ?>
                <h2 class="profile-header">
                    Profile Modification
                </h2>
                <div class="profile-information-c">
                        <div class="profile-head-c">
                            <div class="p-header-m-container">
                                <img src="<?php echo e(asset('icons/profile.png')); ?>" alt="Profile Image" class="p-edit-image">

                                <div class="f-email-container">
                                    <?php if($user): ?>
                                    <h3 class="f-header"><?php echo e($user->name); ?></h3>
                                    <p><?php echo e($user->email); ?></p>
                                    <?php else: ?>
                                        <h3 class="f-header">Guest</h3>
                                        <p>No account info available</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <button type="submit" name="submit" class="edit-Btn">Edit</button>
                        </div>
                        <div class="form-modification-container">
                            <form action="">
                                <div class="f-m-container">
                                    <div class="info-user">
                                        <label for="name">Fullname</label>
                                        <input type="text" name="name" id="name" placeholder="Name" value="<?php echo e($user->name ?? ''); ?>">
                                    </div>
                                    <div class="info-user">
                                        <label for="phone_number">Phone Number</label>
                                        <input type="text" name="name" id="name" placeholder="Name" value="<?php echo e($user->phone_number ?? ''); ?>">
                                    </div>
                                    <div class="info-user">
                                        <label for="address">Address</label>
                                        <input type="text" name="address" id="address" placeholder="Address">
                                    </div>
                                    <div class="info-user">
                                        <label for="email">Email</label>
                                        <input type="text" name="name" id="name" placeholder="Name" value="<?php echo e($user->email ?? ''); ?>">

                                    </div>
                                    <div class="info-user">
                                        <label for="password">Password</label>
                                        <input type="text" name="name" id="name" placeholder="Name" value="<?php echo e($user->password ?? ''); ?>">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <h3 class="my-email">
                            My email Address
                        </h3>
                        <div class="m-email-c">
                             <video autoplay loop muted playsinline class="email-g">
                                <source src="<?php echo e(asset('icons/email.mp4')); ?>" type="video/mp4">
                             </video>
                             <h3><?php echo e($user->password ?? ''); ?></h3>
                        </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.sideBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventory-system\inventory-system\resources\views/customers/profile.blade.php ENDPATH**/ ?>