<?php echo app('Illuminate\Foundation\Vite')(['resources/css/personnel.css', 'resources/js/app.js']); ?>


<?php $__env->startSection('content'); ?>
   <div class="personnel-header-container">
        <h2 class="personnel-header">Personnels</h2>
        <div class="personnel-box">
           <form method="GET" action="<?php echo e(route('users.search')); ?>">
                <input class="personnelForm" name="name" type="text" id="searchPersonnel" placeholder="Quick Search Personnel...">
            </form>
            <button class="addPersonel" type="button" onclick="openAddPersonnelModal()">
                + Create Personnel
            </button>
        </div>
   </div>

   <div class="addPersonelModal" id="addPersonnelModal">
        <h2 class="AP-header">Create Personnel Account</h2>
        <div class="AP-form-container">
            <form method="POST" action="<?php echo e(route('users.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="info-container">
                    <label for="name">Personnel Name:</label>
                    <input type="text" name="name" id="name" placeholder="Fullname..." required>
                </div>
                <div class="info-container">
                    <label for="phone_number">Phone Number:</label>
                    <input type="text" name="phone_number" id="phone_number" placeholder="Phone Number..." required>
                </div>
                <div class="info-container">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" placeholder="Email" required>
                </div>
                <div class="info-container">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" placeholder="Password" required>
                </div>
                <div class="info-container">
                    <label for="roles">Roles:</label>
                    <input list="role-options" name="roles" id="roles" placeholder="Select role..." required>
                    <datalist id="role-options">
                        <option value="Instructor">
                        <option value="Faculty">
                        <option value="Custodian">
                        <option value="Admin">
                    </datalist>
                </div>

                <div class="info-btn">
                    <button type="submit" name="submit">Create</button>
                    <button type="button" name="cancel" onclick="closeAddPersonnelModal()">Cancel</button>
                </div>
            </form>

        </div>
   </div>

   <h2 class="personnel-list-header">Personnel List</h2>
   
    <div class="personnel-list-container">
     <table class="personnel-list-table">
    <thead>
        <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody id="personnelTableBody">
       <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($user->roles !== 'Customers'): ?>
                <?php echo $__env->make('personnel.partials.personnel_table_rows', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->roles); ?></td>
                    <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                    <td>
                        <button>Edit</button>
                        <button>Delete</button>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5">No personnel found.</td>
            </tr>
        <?php endif; ?>

    </tbody>
</table>


    </div>


<?php $__env->stopSection(); ?>
<script>
    function openAddPersonnelModal() {
        document.getElementById('addPersonnelModal').style.display = 'block';
    }

    function closeAddPersonnelModal() {
        document.getElementById('addPersonnelModal').style.display = 'none';
    }

    document.getElementById('searchPersonnel').addEventListener('keyup', function () {
        const query = this.value;

        fetch(`/personnel_dashboard?name=${encodeURIComponent(query)}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById('personnelTableBody').innerHTML = data;
            });
    });
</script>






<?php echo $__env->make('layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventory-system\inventory-system\resources\views/personnel/personnel_dashboard.blade.php ENDPATH**/ ?>