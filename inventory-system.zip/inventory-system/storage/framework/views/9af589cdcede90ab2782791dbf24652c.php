<?php echo app('Illuminate\Foundation\Vite')(['resources/css/gym.css', 'resources/js/app.js']); ?>

    <?php $__env->startSection('content'); ?>
    <div class="gym-main-container">
        <h2 class="gym-header">
            Gym Section
        </h2>
        <div class="gym-main-box-container">
            <div class="gym-box"></div>
            <div class="gym-box"></div>
            <div class="gym-box"></div>
            <div class="gym-box"></div>
        </div>
        <div class="list-header-container">
            <h3 class="list-header">
                List Of Packages
            </h3>
            <button type="button" class="addPackageBtn">
                + Create Package
            </button>
        </div>
        <div class="search-package">
            <input type="text" name="search_package" placeholder="Search Package">
        </div>
       <div class="add-package-modal-container" id="packageModal">
            <h3 class="add-package-header">Create Packages</h3>
            <form action="<?php echo e(route('gym.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="info-container">
                <label for="packages">Suggested Packages</label>
                <input list="packages-list" name="package" id="packages" placeholder="Select Package..." required>
                <datalist id="packages-list">
                    <option value="All-Star Premium Package">
                    <option value="Slam Dunk Package">
                    <option value="Standard Game Package">
                    <option value="Basic Play Package">
                </datalist>
            </div>

            <div class="list-item-info">
                <h3 class="list-head">List Items</h3>

                <div class="list-box-container-items">
                    <?php $__empty_1 = true; $__currentLoopData = $equipmentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="item-group" id="equipment-<?php echo e($equipment->id); ?>">
                            <label>
                                <input type="checkbox" 
                                    name="equipment[]" 
                                    value="<?php echo e($equipment->id); ?>" 
                                    data-equipment="<?php echo e($equipment->equipment); ?>">
                                <?php echo e($equipment->equipment); ?> (<?php echo e($equipment->quantity); ?>)
                            </label>

                            
                            <input type="number" 
                                name="equipment_quantity[<?php echo e($equipment->id); ?>]" 
                                id="quantity-<?php echo e($equipment->id); ?>" 
                                placeholder="Qty" 
                                min="1" 
                                max="<?php echo e($equipment->quantity); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No equipment added yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="add-bottom-container">
                <div class="price">
                    <label for="price">Price:</label>
                    <input type="number" name="price" id="price" placeholder="Enter Price" required>
                </div>
                <div class="add-btn-container">
                    <button type="submit" name="submit">Submit</button>
                    <button type="button" id="closeModalBtn">Close</button>
                </div>
            </div>
            </form>
        </div>

        <div class="package-main-container">
            <div class="package-main-box-container">
    <?php $__empty_1 = true; $__currentLoopData = $gyms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gym): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="package-box">
            <h2 class="package-header">
                <?php echo e($gym->package); ?>

            </h2>

            <h3 class="package-subheader">
                List of Items
            </h3>

            <div class="list-item-container">
                <ul>
                    <?php $__currentLoopData = $gym->equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($equipment->pivot->quantity); ?> <?php echo e($equipment->equipment); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <div class="package-bottom-container">
                <h3 class="total-header">
                    Price: ₱ <?php echo e(number_format($gym->price, 2)); ?>

                </h3>

                <div class="edit-delete-container">
                    
                    <img src="<?php echo e(asset('icons/edit.png')); ?>" 
                         alt="Edit Package" 
                         class="edit-image" 
                         style="cursor:pointer;"
                         onclick="openModal(<?php echo e($gym->id); ?>)"
                         data-id="<?php echo e($gym->id); ?>"
                         data-package="<?php echo e($gym->package); ?>"
                         data-price="<?php echo e(number_format($gym->price, 2)); ?>"
                         data-equipment='<?php echo json_encode($gym->equipment->map(fn($e) => [
                             "name" => $e->equipment, "qty"  => $e->pivot->quantity
                         ]), 512) ?>'>

                    
                    <form action="<?php echo e(route('gym.destroy', $gym->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" style="border:none; background:none; padding:0;">
                            <img src="<?php echo e(asset('icons/trash.png')); ?>" 
                                 alt="Delete Package" 
                                 class="edit-image" 
                                 style="cursor:pointer;">
                        </button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No packages available.</p>
    <?php endif; ?>
</div>

        </div>
    </div>
    <script>
document.querySelector('.addPackageBtn').addEventListener('click', function() {
    document.getElementById('packageModal').style.display = 'block';
});

document.getElementById('closeModalBtn').addEventListener('click', function() {
    document.getElementById('packageModal').style.display = 'none';
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventory-system\inventory-system\resources\views/settings/gym.blade.php ENDPATH**/ ?>