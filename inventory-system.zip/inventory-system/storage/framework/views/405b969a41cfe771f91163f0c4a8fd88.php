<?php echo app('Illuminate\Foundation\Vite')(['resources/css/services.css', 'resources/js/app.js']); ?>

<?php $__env->startSection('content'); ?>
    <div class="services-header">
            <h2 class="services-H">Our Services</h2>
            <p class="services-P">
                Our basketball gym reservation service makes it easy to book your workout schedule in advance.<br>
                This ensures an organized experience, prevents overcrowding,<br>
                and provides flexibility for personal training, group classes, or individual sessions.
            </p>
       </div>

       <div class="services-container">
            <div class="service-b">
               <h3>📅 Schedule Management</h3>
                <p>Stay updated with your court bookings anytime, ensuring smooth planning for practices, games, and events.</p>
                <p>View and manage your upcoming reservations in one organized calendar, avoiding conflicts and overlaps.</p>
            </div>
            <img src="<?php echo e(asset('system-images/s.png')); ?>" alt="Login Image" class="s-img">
            <div class="service-b">
               <h3>⭐ Event Hosting</h3>
                <p>Enjoy a professional and well-maintained venue that can accommodate both small gatherings and large tournaments.</p>
                <p>Use the gym for basketball events, competitions, and school activities with hassle-free coordination.</p>
            </div>
       </div>
       <div class="services-container">
            <img src="<?php echo e(asset('system-images/f.png')); ?>" alt="Login Image" class="ss-img">
            <div class="service-b">
                <h3>📅 Schedule Management</h3>
                <p>Stay updated with your court bookings anytime, ensuring smooth planning for practices, games, and events.</p>
                <p>View and manage your upcoming reservations in one organized calendar, avoiding conflicts and overlaps.</p>
            </div>
            <div class="service-b">
               <h3>⭐ Event Hosting</h3>
                <p>Enjoy a professional and well-maintained venue that can accommodate both small gatherings and large tournaments.</p>
                <p>Use the gym for basketball events, competitions, and school activities with hassle-free coordination.</p>
            </div>
            <img src="<?php echo e(asset('system-images/d.png')); ?>" alt="Login Image" class="ss-img">
       </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventory-system\inventory-system\resources\views/customers/userServices.blade.php ENDPATH**/ ?>