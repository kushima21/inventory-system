<?php echo app('Illuminate\Foundation\Vite')(['resources/css/equipment.css', 'resources/js/app.js']); ?>
<?php $__env->startSection('content'); ?>
    <div class="additional-equipment-main-container">
        <h2 class="additional-equipment-header">
            Add Equipment Bundle
        </h2>
        <h3 class="list-equipment-bundle">
            List of Equipment Bundled
        </h3>
        <div class="addtional-container-box">
            <div class="additional-subheader-container">
                <input type="text" name="search" id="search-equipment" placeholder="Quick Search...">
                <button type="button" class="createBundle">
                    + Create Equipment Bundle
                </button>
            </div>
            <div class="additional-modal">
                <h3 class="additional-header-modal">
                    Add Equipment Bundle
                </h3>
                <div class="additional-form-container">
                    <form method="POST" action="<?php echo e(route('equipment.bundle.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="additional-modal-info">
                            <label for="equipment">Select Equipment</label>
                            <select name="equipment" id="equipment">
                                <option value="">Select Equipment</option>
                                <?php $__currentLoopData = $equipmentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($equipment->id); ?>">
                                        <?php echo e($equipment->equipment); ?> — <?php echo e($equipment->quantity); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="additional-modal-info">
                            <label for="quantity">Quantity</label>
                            <input type="number" name="quantity" id="quantity" required>
                        </div>
                        <div class="additional-modal-info">
                            <label for="price">Price</label>
                            <input type="number" name="price" id="price" required>
                        </div>
                        <div class="additional-button-container">
                            <button type="submit" name="submit">Submit</button>
                            <button type="button" class="closeModal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="additional-wrapper-container-equipment">
    <table class="additional-equipment-table">
        <thead>
            <tr>
                <th>Created</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bundles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bundle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($bundle->created_at->format('Y-m-d')); ?></td>
                    <td><?php echo e($bundle->equipment->equipment ?? 'N/A'); ?></td>
                    <td><?php echo e($bundle->quantity); ?> Pieces</td>
                    <td><?php echo e(number_format($bundle->price, 2)); ?></td>
                    <td>
                        <button class="editBTn" type="button">Edit</button>
                        <form action="<?php echo e(route('equipment.bundle.delete', $bundle->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="deleteBTn" onclick="return confirm('Are you sure you want to delete this bundle?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="text-align: center;">No bundles found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

        </div>
    </div>
    <script>
    // Get the buttons and modal
    const openBtn = document.querySelector('.createBundle');
    const closeBtn = document.querySelector('.closeModal');
    const modal = document.querySelector('.additional-modal');

    // Show modal on button click
    openBtn.addEventListener('click', () => {
        modal.style.display = 'block';
    });

    // Hide modal on close button click
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Optional: hide modal if click outside the modal content
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventory-system\inventory-system\resources\views/settings/equipment.blade.php ENDPATH**/ ?>