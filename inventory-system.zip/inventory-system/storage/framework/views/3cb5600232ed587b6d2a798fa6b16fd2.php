<?php echo app('Illuminate\Foundation\Vite')(['resources/css/sideBar.css', 'resources/js/app.js']); ?>
<?php
$user = \App\Models\User::find(session('user_id'));
?>
<?php $__env->startSection('content'); ?>
    <div class="sideBar-main-Container">
        <div class="main-bar-container">
            <div class="left-b-container">
                <div class="l-h-container">
                    <img src="<?php echo e(asset('icons/basket-ball.png')); ?>" alt="basket Image" class="ball-img">
                    <h3 class="l-header">
                        LSSTI Basketball Gym Reservation
                    </h3>
                </div>
                <div class="l-m-container">
                    <div class="link-c">
                        <a href="<?php echo e(url('/customers/profile')); ?>">
                            <div class="link-box">
                                <img src="<?php echo e(asset('icons/profile.png')); ?>" alt="Profile Image" class="user-image">
                                <h3>Profile Modification</h3>
                               
                            </div>
                        </a>
                        <a href="<?php echo e(route('bookings.list')); ?>">
                            <div class="link-box">
                                <img src="<?php echo e(asset('icons/booking.png')); ?>" alt="Profile Image" class="user-image">
                                <h3>Booking Request</h3>
                            </div>
                        </a>

                    </div>
                </div>

            </div>
            <div class="right-b-container">
                <?php echo $__env->yieldContent('Sidecontent'); ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const logoutBtn = document.getElementById('logoutBtn');
    const logoutForm = document.getElementById('logoutForm');

    logoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        Swal.fire({
            title: 'Are you sure you want to logout?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, logout'
        }).then((result) => {
            if (result.isConfirmed) {
                logoutForm.submit(); // submit POST logout
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\inventory-system\inventory-system\resources\views/partials/sideBar.blade.php ENDPATH**/ ?>