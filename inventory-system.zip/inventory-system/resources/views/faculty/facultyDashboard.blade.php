@extends('layout.faculty')
@vite(['resources/css/faculty.css', 'resources/js/app.js'])

@section('content')
    <div class="faculty-dashboard-main-container">
        <h2 class="faculty-subheader-dashboard">
            Some features are not yet covered, may introduce breaking changes, and can change at any time.
        </h2>
        <h3 class="faculty-dashboard-header">
            /* Welcome to your LSSTI Network Dashboard
        </h3>
    </div>
@endsection